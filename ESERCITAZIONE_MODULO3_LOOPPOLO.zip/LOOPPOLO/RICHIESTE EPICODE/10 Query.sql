-- 1) Restituire tutti i nomi e i gradi alcolici delle birre, ordinati per per Nome_Birra SENZA UTILIZZARE JOIN
SELECT Birra.Nome_Birra, Descrizione_Birra.Grado_Alcolico
FROM Birra, Descrizione_Birra
WHERE Birra.ID_Birra = Descrizione_Birra.ID_Birra
ORDER BY Nome_Birra

-- 2) Quanti colli ho consegnato per ogni cliente? Restituire il tutto in ordine DECRESCENTE per numero ordini
SELECT Anagrafica_Cliente.Nome_Cliente, COUNT(Dettagli_Ordine.ID_DettagliOrdine) AS Numero_Ordini
FROM Cliente, Anagrafica_Cliente
JOIN Dettagli_Ordine
ON Anagrafica_Cliente.ID_Cliente = Dettagli_Ordine.ID_Cliente
WHERE Cliente.ID_Cliente = Anagrafica_Cliente.ID_Cliente AND Cliente.ID_Cliente = Dettagli_Ordine.ID_Cliente AND Dettagli_Ordine.Flag_Consegnato = 1
GROUP BY Anagrafica_Cliente.Nome_Cliente
ORDER BY Numero_Ordini DESC

-- 3) Quante birre hanno ordinato per ogni regione? Restituire il tutto in ordine DECRESCENTE per numero birre ordinate senza utilizzare JOIN
SELECT Regione.Regione, COUNT(Dettagli_Ordine.ID_Birra) AS Numero_Birre_Vendute
FROM Regione, Anagrafica_Cliente, Dettagli_Ordine
WHERE Regione.ID_Regione = Anagrafica_Cliente.ID_Regione AND Anagrafica_Cliente.ID_Cliente = Dettagli_Ordine.ID_Cliente
GROUP BY Regione.Regione
ORDER BY Numero_Birre_Vendute DESC

-- 4) Quanti ordini hanno effettuato per ogni regione? Restituire il tutto in ordine DECRESCENTE per ordini consegnati.
SELECT Regione.Regione, COUNT(Ordine.ID_Ordine) AS Numero_Ordini
FROM Regione
JOIN Anagrafica_Cliente
ON Regione.ID_Regione = Anagrafica_Cliente.ID_Regione
JOIN Dettagli_Ordine
ON Anagrafica_Cliente.ID_Cliente = Dettagli_Ordine.ID_Cliente
JOIN Ordine
ON Ordine.ID_Ordine = Dettagli_Ordine.ID_DettagliOrdine
GROUP BY Regione.Regione
ORDER BY Numero_Ordini DESC

-- 5) Selezionare il nome, prezzo medio e numero totale di ordini effettuati per birra, Restituire il tutto in ordine DECRESCENTE per prezzo medio, senza utilizzare JOIN
SELECT Birra.Nome_Birra, AVG(Dettagli_Ordine.Prezzo_Unitario) AS Prezzo_Medio, COUNT(Dettagli_Ordine.ID_Ordine) AS Numero_Ordini
FROM Birra, Descrizione_Birra, Dettagli_Ordine
WHERE Birra.ID_Birra = Descrizione_Birra.ID_Birra AND Birra.ID_Birra = Dettagli_Ordine.ID_Birra
GROUP BY Birra.Nome_Birra
ORDER BY Prezzo_Medio DESC

-- 6) Nome cliente, indirizzo mail e numero ordini effettuati. Restituire il tutto in ordine DECRESCENTE per numero ordini.
SELECT Anagrafica_Cliente.Nome_Cliente, Anagrafica_Cliente.Mail, COUNT(Ordine.ID_Ordine) AS Numero_Ordini
FROM Anagrafica_Cliente
JOIN Cliente
ON Cliente.ID_Cliente = Anagrafica_Cliente.ID_Cliente
JOIN Dettagli_Ordine
ON Dettagli_Ordine.ID_Cliente = Cliente.ID_Cliente
JOIN Ordine
ON Dettagli_Ordine.ID_Ordine = Ordine.ID_Ordine
GROUP BY Anagrafica_Cliente.Nome_Cliente, Anagrafica_Cliente.Mail
ORDER BY Numero_Ordini DESC

-- 7) Tutte le birre che sono state ordinate almeno una volta ed hanno grado alcolico maggiore o uguale a 5
SELECT Birra.Nome_Birra, Descrizione_Birra.Grado_Alcolico
FROM Birra
JOIN Descrizione_Birra 
ON Birra.ID_Birra = Descrizione_Birra.ID_Birra
WHERE Descrizione_Birra.Grado_Alcolico >= 5 AND Birra.ID_Birra IN (
    SELECT Dettagli_Ordine.ID_Birra
    FROM Dettagli_Ordine
    JOIN Ordine ON Dettagli_Ordine.ID_Ordine = Ordine.ID_Ordine
    WHERE Ordine.Flag_Consegnato = 1
)
ORDER BY Birra.Nome_Birra ASC

-- 8) Tutti i clienti che hanno ordinato almeno una volta, prezzo medio delle birre acquistate da loro. Restituire il tutto per prezzo medio decrescente.
SELECT Anagrafica_Cliente.Nome_Cliente, AVG(Dettagli_Ordine.Prezzo_Unitario) AS Prezzo_Medio
FROM Anagrafica_Cliente
JOIN Cliente 
ON Anagrafica_Cliente.ID_Cliente = Cliente.ID_Cliente
JOIN Dettagli_Ordine 
ON Cliente.ID_Cliente = Dettagli_Ordine.ID_Cliente
GROUP BY Anagrafica_Cliente.Nome_Cliente
HAVING COUNT(*) >= 1
ORDER BY Prezzo_Medio DESC

-- 9) Mostrare il numero di ordini spediti per ogni cliente, raggruppare per regione e ordinare il tutto per nome della regione.
SELECT Anagrafica_Cliente.Nome_Cliente,Regione.Regione, COUNT(*) AS Numero_Ordini_Spediti
FROM Regione
JOIN Anagrafica_Cliente
ON Regione.ID_Regione = Anagrafica_Cliente.ID_Regione
JOIN Cliente 
ON Anagrafica_Cliente.ID_Cliente = Cliente.ID_Cliente
JOIN (
    SELECT ID_Cliente
    FROM Dettagli_Ordine
    WHERE Flag_Spedito = 1
    GROUP BY ID_Cliente
) AS Ordini_Spediti ON Cliente.ID_Cliente = Ordini_Spediti.ID_Cliente
GROUP BY Regione.Regione,Anagrafica_Cliente.Nome_Cliente
ORDER BY Regione.Regione

--10) Per ogni cliente, calcolare: Spesa totale fatta e ordinare per spesa totale in ordine decrescente. Limitarsi solo ai clienti che hanno almeno un ordine spedito.
SELECT Anagrafica_Cliente.Nome_Cliente, SUM(Dettagli_Ordine.Totale) AS Spesa_Totale
FROM Anagrafica_Cliente
JOIN Cliente 
ON Anagrafica_Cliente.ID_Cliente = Cliente.ID_Cliente
JOIN Dettagli_Ordine 
ON Cliente.ID_Cliente = Dettagli_Ordine.ID_Cliente
WHERE Dettagli_Ordine.Flag_Spedito = 1
GROUP BY Anagrafica_Cliente.Nome_Cliente
HAVING SUM(Dettagli_Ordine.Totale) >= 1
ORDER BY Spesa_Totale DESC
