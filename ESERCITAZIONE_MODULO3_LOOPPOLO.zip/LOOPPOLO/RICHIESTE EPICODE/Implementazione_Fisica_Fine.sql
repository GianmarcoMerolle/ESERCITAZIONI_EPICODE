CREATE DATABASE Luppolo

CREATE TABLE Birra (
  ID_Birra INT NOT NULL,
  Nome_Birra VARCHAR(255) NOT NULL,
  PRIMARY KEY (ID_Birra)
)

CREATE TABLE Descrizione_Birra (
  ID_Birra INT NOT NULL,
  Nome_Birra VARCHAR(255) NOT NULL,
  Descrizione VARCHAR(255) NOT NULL,
  Anno INT NOT NULL,
  Grado_Alcolico FLOAT NOT NULL,
  PRIMARY KEY (ID_Birra),
  FOREIGN KEY (ID_Birra) REFERENCES Birra(ID_Birra)
)

CREATE TABLE Regione (
  ID_Regione INT NOT NULL,
  Nazione VARCHAR(255) NOT NULL,
  Regione VARCHAR(255) NOT NULL,
  Provincia VARCHAR(255) NOT NULL,
  PRIMARY KEY (ID_Regione)
)

CREATE TABLE Cliente (
  ID_Cliente INT NOT NULL,
  Nome_Cliente VARCHAR(255) NOT NULL,
  PRIMARY KEY (ID_Cliente)
)

CREATE TABLE Anagrafica_Cliente (
  ID_Cliente INT NOT NULL,
  Nome_Cliente VARCHAR(255) NOT NULL,
  ID_Regione INT NOT NULL,
  Mail VARCHAR(255) NOT NULL,
  Cellulare VARCHAR(255) NOT NULL,
  PRIMARY KEY (ID_Cliente),
  FOREIGN KEY (ID_Cliente) REFERENCES Cliente(ID_Cliente),
  FOREIGN KEY (ID_Regione) REFERENCES Regione(ID_Regione)
)

CREATE TABLE Ordine (
  ID_Ordine INT NOT NULL,
  Flag_Spedito INT NOT NULL,
  Flag_Consegnato INT NOT NULL,
  Totale FLOAT NOT NULL,
  PRIMARY KEY (ID_Ordine)
)

CREATE TABLE Dettagli_Ordine (
  ID_Ordine INT NOT NULL,
  ID_DettagliOrdine INT NOT NULL,
  ID_Birra INT NOT NULL,
  Quantit� INT NOT NULL,
  ID_Cliente INT NOT NULL,
  Flag_Spedito INT NOT NULL,
  Flag_Consegnato INT NOT NULL,
  Prezzo_Unitario FLOAT NOT NULL,
  Indirizzo VARCHAR(255) NOT NULL,
  Totale FLOAT NOT NULL,
  PRIMARY KEY (ID_DettagliOrdine),
  FOREIGN KEY (ID_Ordine) REFERENCES Ordine(ID_Ordine),
  FOREIGN KEY (ID_Birra) REFERENCES Birra(ID_Birra),
  FOREIGN KEY (ID_Cliente) REFERENCES Cliente(ID_Cliente)
)

DROP TABLE Dettagli_Ordine