INSERT INTO Birra (ID_Birra, Nome_Birra)
VALUES (1, 'IPA'),
       (2, 'Pilsner'),
       (3, 'Stout'),
       (4, 'Blonde Ale'),
       (5, 'Weissbier')

INSERT INTO Descrizione_Birra (ID_Birra, Nome_Birra, Descrizione, Anno, Grado_Alcolico)
VALUES (1, 'IPA', 'Birra ad alta fermentazione con forte aroma di luppolo', 2018, 6.5),
       (2, 'Pilsner', 'Birra di tipo Pilsner con gusto leggero e fresco', 2019, 4.8),
       (3, 'Stout', 'Birra scura con note di cioccolato e caff�', 2017, 7.2),
       (4, 'Blonde Ale', 'Birra dorata e leggera con sentori di frutta', 2020, 5.0),
       (5, 'Weissbier', 'Birra di frumento tedesca con sentori di banana e chiodi di garofano', 2019, 5.4)

INSERT INTO Regione (ID_Regione, Nazione, Regione, Provincia)
VALUES (1, 'Italia', 'Lombardia', 'Milano'),
       (2, 'Italia', 'Veneto', 'Venezia'),
       (3, 'Germania', 'Baviera', 'Monaco'),
       (4, 'Belgio', 'Fiandre', 'Anversa'),
       (5, 'USA', 'California', 'San Diego')

INSERT INTO Cliente (ID_Cliente, Nome_Cliente)
VALUES (1, 'Mario Rossi'),
       (2, 'Giulia Bianchi'),
       (3, 'Luca Neri'),
       (4, 'Marco Verdi'),
       (5, 'Alessia Russo')

INSERT INTO Anagrafica_Cliente (ID_Cliente, Nome_Cliente, ID_Regione, Mail, Cellulare)
VALUES (1, 'Mario Rossi', 1, 'mario.rossi@email.com', '+39 123456789'),
       (2, 'Giulia Bianchi', 2, 'giulia.bianchi@email.com', '+39 987654321'),
       (3, 'Luca Neri', 1, 'luca.neri@email.com', '+39 555555555'),
       (4, 'Marco Verdi', 3, 'marco.verdi@email.com', '+49 123456789'),
       (5, 'Alessia Russo', 4, 'alessia.russo@email.com', '+32 987654321');

INSERT INTO Ordine (ID_Ordine, Flag_Spedito, Flag_Consegnato, Totale)
VALUES (1, 1, 0, 30.50),
       (2, 0, 0, 20.00),
       (3, 1, 1, 45.00),
       (4, 1, 1, 25.00),
       (5, 0, 0, 15.00)

INSERT INTO Dettagli_Ordine (ID_DettagliOrdine, ID_Birra, Quantit�, ID_Cliente, ID_Ordine, Flag_Spedito, Flag_Consegnato, Prezzo_Unitario, Indirizzo, Totale)
VALUES (1, 1, 3, 1, 1, 1, 0, 5.50, 'Via Roma, 1, Milano', 16.50),
       (2, 2, 3, 1, 1, 1, 0, 3.00, 'Via Roma, 1, Milano', 9.00),
       (3, 3, 3, 2, 2, 0, 0, 4.00, 'Via Venezia, 10, Venezia', 12.00),
       (4, 1, 4, 3, 3, 1, 1, 5.50, 'Via Garibaldi, 5, Milano', 22.00),
       (5, 4, 5, 4, 4, 1, 1, 4.50, 'Hauptstra�e, 15, Monaco', 22.50),
       (6, 5, 3, 5, 5, 0, 0, 3.00, 'Rue de la Loi, 20, Bruxelles', 9.00)